
import xmlrpclib
import csv

path = '/home/fims/Downloads/sample_data.csv'

username = 'admin' #the user
pwd = 'admin'      #the password of the user
dbname = 'test_10_comm'    #the database
url = 'http://0.0.0.0:8069'

sock_common = xmlrpclib.ServerProxy (url+'/xmlrpc/common')
uid = sock_common.login(dbname, username, pwd)
sock = xmlrpclib.ServerProxy(url+'/xmlrpc/object',allow_none=True)

# workbook = xlrd.open_workbook(path)
# worksheet = workbook.sheet_by_index(0)

file1 = open(path, 'rb')
reader = csv.reader(file1)

offset = 1
h = 0
new_rows_list = []
for i, row in enumerate(reader):
    print "~~~~~~~~~~~~~~~~~~~~~", row
    row.append(reader)
    vals={}
    print "~~~~~~~~~~~row~~~~~~~~~~", row