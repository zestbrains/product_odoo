from openerp import api, fields, models

class ProductTemplate(models.Model):
    _inherit = 'product.template'

    brand_id = fields.Many2one('product.brand', string='Brand Name')
    model_id = fields.Many2one('product.model', string='Model Name')
    amp = fields.Float('Amp')
    volts = fields.Integer('Volts')
    location = fields.Char('Location')
    actual_voltage = fields.Integer('Actual Voltage')
    actual_amp = fields.Float('Actual Amp')
    bearings = fields.Boolean('Bearings')
    lubrication = fields.Boolean('Lubrication')
    seal = fields.Boolean('Seal')
    paint = fields.Boolean('Paint')
    cleaning = fields.Boolean('Cleaning')
    impulsor = fields.Boolean('Impulsor')

class ProductBrand(models.Model):
    _name = 'product.brand'

    code = fields.Char('Code')
    name = fields.Char('name')

class ProductModel(models.Model):
    _name = 'product.model'

    code = fields.Char('Code')
    name = fields.Char('name')