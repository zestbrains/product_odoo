# -*- coding: utf-8 -*-
{
    "name": "ZB Product Extend",
    "version": "10.0",
    "author": "ZestBrains INC.",
    "website": "www.fortuneims.com",
    "depends": ['product'],
    "category": "",
    "data": [
             'views/product_extend.xml',
             ],
    "installable": True,
    "application": True,
}
